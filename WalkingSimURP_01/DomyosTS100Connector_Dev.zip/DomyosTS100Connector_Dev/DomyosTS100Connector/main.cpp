// DomyosTS100Connector
//
// Standalone BLE discovery/connection tool for the Domyos TS100 treadmill,
// modeled after qdomyos-zwift's src/devices/bluetooth.cpp (device discovery)
// and src/devices/horizontreadmill/horizontreadmill.cpp (FTMS data decoding).
//
// The TS100 is a modern Domyos unit that speaks the standard Bluetooth SIG
// "Fitness Machine Service" (FTMS, UUID 0x1826), advertised under a name
// starting with "DOMYOS-TC". It has a fixed, non-adjustable 15-degree
// incline and does not report an inclination value over BLE.
//
// This tool:
//   1. Scans for BLE advertisements and logs every device it sees (so you
//      can tell whether Windows can see the treadmill at all).
//   2. Highlights and auto-connects to the first device whose advertised
//      name starts with "DOMYOS".
//   3. Discovers the FTMS service (0x1826) and Treadmill Data
//      characteristic (0x2ACD), subscribes to notifications, and decodes
//      live speed / distance / incline exactly like horizontreadmill.cpp.

// winsock2.h must be included before anything that drags in windows.h
// (which the WinRT headers below do) -- windows.h pulls in the legacy
// winsock.h otherwise, and winsock.h + winsock2.h in the same translation
// unit is a hard redefinition-error conflict.
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "Ws2_32.lib")

#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Devices.Bluetooth.h>
#include <winrt/Windows.Devices.Bluetooth.Advertisement.h>
#include <winrt/Windows.Devices.Bluetooth.GenericAttributeProfile.h>
#include <winrt/Windows.Storage.Streams.h>

#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <map>
#include <mutex>
#include <atomic>
#include <conio.h>
#include <chrono>
#include <thread>

using namespace winrt;
using namespace winrt::Windows::Foundation;
using namespace winrt::Windows::Devices::Bluetooth;
using namespace winrt::Windows::Devices::Bluetooth::Advertisement;
using namespace winrt::Windows::Devices::Bluetooth::GenericAttributeProfile;
using namespace winrt::Windows::Storage::Streams;

namespace {

// Builds the full 128-bit Bluetooth UUID for a standard 16-bit "short" UUID,
// e.g. ShortUuid(0x1826) -> 00001826-0000-1000-8000-00805F9B34FB
// (Qt does this internally in QBluetoothUuid((quint16)0x1826); WinRT has no
// built-in helper for it, so we replicate the Bluetooth Base UUID formula.)
guid ShortUuid(uint16_t shortId) {
    return guid{
        static_cast<uint32_t>(shortId),
        0x0000,
        0x1000,
        {0x80, 0x00, 0x00, 0x80, 0x5F, 0x9B, 0x34, 0xFB}
    };
}

constexpr uint16_t FTMS_SERVICE_UUID = 0x1826;
constexpr uint16_t TREADMILL_DATA_CHARACTERISTIC_UUID = 0x2ACD;

std::wstring FormatServiceUuids(winrt::Windows::Foundation::Collections::IVector<guid> const& uuids) {
    std::wstringstream ss;
    bool first = true;
    for (auto&& id : uuids) {
        if (!first) ss << L", ";
        first = false;
        ss << winrt::to_hstring(id).c_str();
    }
    return ss.str();
}

bool HasFtmsService(winrt::Windows::Foundation::Collections::IVector<guid> const& uuids) {
    guid ftms = ShortUuid(FTMS_SERVICE_UUID);
    for (auto&& id : uuids) {
        if (id == ftms) return true;
    }
    return false;
}

std::wstring HexAddress(uint64_t address) {
    std::wstringstream ss;
    ss << std::hex << std::uppercase << std::setfill(L'0');
    for (int shift = 40; shift >= 0; shift -= 8) {
        ss << std::setw(2) << ((address >> shift) & 0xFF);
        if (shift != 0) ss << L":";
    }
    return ss.str();
}

std::mutex g_consoleMutex;

// --- TCP server: streams decoded treadmill data to a local client (Unity).
// One-way, single-client, best-effort: if nothing is connected, sends are
// simply skipped rather than buffered or blocked on, so this never affects
// BLE handling regardless of whether Unity is running.
constexpr uint16_t TCP_LISTEN_PORT = 5005;

std::mutex g_clientSocketMutex;
SOCKET g_clientSocket = INVALID_SOCKET;

// Runs for the lifetime of the process on its own thread: repeatedly
// accepts one client at a time (closing out the previous one, if any),
// since Unity's Play/Stop cycle will connect and disconnect this repeatedly
// while the connector itself keeps running continuously.
void TcpServerThreadProc() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::wcout << L"[TCP] WSAStartup failed; Unity streaming will not be available." << std::endl;
        return;
    }

    SOCKET listenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (listenSocket == INVALID_SOCKET) {
        std::wcout << L"[TCP] Failed to create listening socket (error " << WSAGetLastError() << L")." << std::endl;
        return;
    }

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(TCP_LISTEN_PORT);
    inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);

    if (bind(listenSocket, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == SOCKET_ERROR) {
        std::wcout << L"[TCP] Failed to bind port " << TCP_LISTEN_PORT << L" (error " << WSAGetLastError()
                    << L"). Is another instance of this app already running?" << std::endl;
        closesocket(listenSocket);
        return;
    }

    if (listen(listenSocket, 1) == SOCKET_ERROR) {
        std::wcout << L"[TCP] listen() failed (error " << WSAGetLastError() << L")." << std::endl;
        closesocket(listenSocket);
        return;
    }

    std::wcout << L"[TCP] Listening on 127.0.0.1:" << TCP_LISTEN_PORT << L" for a Unity connection." << std::endl;

    while (true) {
        SOCKET accepted = accept(listenSocket, nullptr, nullptr);
        if (accepted == INVALID_SOCKET) {
            continue; // transient accept error -- keep serving
        }

        {
            std::lock_guard<std::mutex> lock(g_clientSocketMutex);
            if (g_clientSocket != INVALID_SOCKET) {
                closesocket(g_clientSocket);
            }
            g_clientSocket = accepted;
        }

        std::lock_guard<std::mutex> lock(g_consoleMutex);
        std::wcout << L"[TCP] Unity client connected." << std::endl;
    }
}

// Sends one line to the connected client, if any. Silently does nothing if
// no client is connected. On a send failure (client went away), closes and
// clears the socket so the app doesn't keep trying to write to a dead
// connection -- the accept loop above will pick up the next Unity session.
void SendLineToUnity(const std::string& line) {
    std::lock_guard<std::mutex> lock(g_clientSocketMutex);
    if (g_clientSocket == INVALID_SOCKET) return;

    int sent = send(g_clientSocket, line.c_str(), static_cast<int>(line.size()), 0);
    if (sent == SOCKET_ERROR) {
        closesocket(g_clientSocket);
        g_clientSocket = INVALID_SOCKET;
    }
}

struct SeenInfo {
    bool logged = false;
    bool hadName = false;
    bool hadUuids = false;
};

// Mirrors the Flags bitfield layout parsed in horizontreadmill.cpp's
// characteristicChanged() for the 0x2ACD Treadmill Data characteristic
// (Bluetooth FTMS spec, "Treadmill Data" section).
struct TreadmillDataFlags {
    uint16_t raw;
    bool moreData()             const { return raw & (1 << 0); } // inverted: 1 = speed NOT present
    bool avgSpeedPresent()      const { return raw & (1 << 1); }
    bool totalDistancePresent() const { return raw & (1 << 2); }
    bool inclinationPresent()   const { return raw & (1 << 3); }
    bool elevationGainPresent() const { return raw & (1 << 4); }
};

// Set by TogglePause() below. Checked here as a fast, always-effective local
// mute: even if a stray notification slips through right as the GATT
// unsubscribe write is still in flight (or a peripheral's BLE stack doesn't
// honor the CCCD write promptly), nothing gets printed while paused.
std::atomic<bool> g_paused{ false };

// Measures the real, observed gap between notifications -- this is not a
// setting anywhere in the app (the connector never polls; it only reacts to
// whatever the treadmill's firmware chooses to push), so the only way to
// know the actual rate is to time it directly.
std::chrono::steady_clock::time_point g_lastNotifyTime{};
bool g_haveLastNotifyTime = false;

void DecodeAndPrintTreadmillData(const IBuffer& buffer) {
    if (g_paused) return;

    auto now = std::chrono::steady_clock::now();
    std::wstring rateStr;
    if (g_haveLastNotifyTime) {
        double deltaMs = std::chrono::duration<double, std::milli>(now - g_lastNotifyTime).count();
        std::wstringstream rs;
        rs << L"dt=" << std::fixed << std::setprecision(0) << deltaMs << L"ms (~"
           << std::setprecision(2) << (1000.0 / deltaMs) << L"Hz) ";
        rateStr = rs.str();
    }
    g_lastNotifyTime = now;
    g_haveLastNotifyTime = true;

    auto reader = DataReader::FromBuffer(buffer);
    uint32_t length = buffer.Length();
    if (length < 2) return;

    std::vector<uint8_t> bytes(length);
    reader.ReadBytes(bytes);

    TreadmillDataFlags flags{ static_cast<uint16_t>(bytes[0] | (bytes[1] << 8)) };
    size_t index = 2;

    // Hoisted out of the per-flag blocks below so they're available
    // afterwards to build the line sent to Unity, regardless of which
    // flags this particular packet happened to set.
    double speedKmh = 0.0;
    double distanceKm = 0.0;
    double inclineDeg = 15.0; // TS100 default: fixed, non-adjustable incline

    std::wstringstream out;
    out << L"[TreadmillData] " << rateStr;

    if (!flags.moreData() && index + 2 <= bytes.size()) {
        uint16_t rawSpeed = static_cast<uint16_t>(bytes[index] | (bytes[index + 1] << 8));
        speedKmh = rawSpeed / 100.0;
        out << L"Speed=" << std::fixed << std::setprecision(2) << speedKmh << L"km/h ";
        index += 2;
    }

    if (flags.avgSpeedPresent()) index += 2;

    if (flags.totalDistancePresent() && index + 3 <= bytes.size()) {
        uint32_t rawDistance = static_cast<uint32_t>(bytes[index]) |
                                (static_cast<uint32_t>(bytes[index + 1]) << 8) |
                                (static_cast<uint32_t>(bytes[index + 2]) << 16);
        distanceKm = rawDistance / 1000.0;
        out << L"Distance=" << std::fixed << std::setprecision(3) << distanceKm << L"km ";
        index += 3;
    }

    // The TS100 has a fixed, non-adjustable 15-degree incline and does not
    // report an inclination field over BLE at all (matches the
    // domyos_treadmill_ts100 special case in horizontreadmill.cpp).
    if (flags.inclinationPresent() && index + 4 <= bytes.size()) {
        int16_t rawIncline = static_cast<int16_t>(bytes[index] | (bytes[index + 1] << 8));
        inclineDeg = rawIncline / 10.0;
        out << L"Inclination=" << inclineDeg << L"deg ";
        index += 4;
    } else {
        out << L"Inclination=15deg(fixed/TS100) ";
    }

    {
        std::lock_guard<std::mutex> lock(g_consoleMutex);
        std::wcout << out.str() << std::endl;
    }

    // Plain "key=value;..." text, one line per update -- simple enough to
    // parse on the Unity/C# side without needing a JSON library for three
    // numbers. Units match what's printed above: km/h, km, degrees.
    std::ostringstream unityLine;
    unityLine << "speed=" << std::fixed << std::setprecision(2) << speedKmh
              << ";distance=" << std::setprecision(3) << distanceKm
              << ";incline=" << std::setprecision(2) << inclineDeg << "\n";
    SendLineToUnity(unityLine.str());
}

// These must stay alive for as long as we want notifications to keep
// arriving: once the coroutine that creates them returns, any local
// variable holding them would be destroyed and the underlying GATT
// connection torn down immediately. Keeping them at global scope, rather
// than local to ConnectAndSubscribe, is what keeps the subscription alive.
BluetoothLEDevice g_device{ nullptr };
GattDeviceService g_ftmsService{ nullptr };
GattCharacteristic g_treadmillDataChar{ nullptr };

IAsyncAction ConnectAndSubscribe(uint64_t bluetoothAddress) {
    std::wcout << L"\nConnecting to " << HexAddress(bluetoothAddress) << L" ..." << std::endl;

    BluetoothLEDevice device = co_await BluetoothLEDevice::FromBluetoothAddressAsync(bluetoothAddress);
    if (device == nullptr) {
        std::wcout << L"FromBluetoothAddressAsync returned null. The OS could not create a device object "
                       L"for this address (it may have gone out of range, or Windows Bluetooth needs a reset)."
                    << std::endl;
        co_return;
    }
    std::wcout << L"Connected: " << device.Name().c_str() << std::endl;
    g_device = device;

    GattDeviceServicesResult servicesResult =
        co_await device.GetGattServicesForUuidAsync(ShortUuid(FTMS_SERVICE_UUID), BluetoothCacheMode::Uncached);

    if (servicesResult.Status() != GattCommunicationStatus::Success) {
        std::wcout << L"Could not query GATT services on this device.\n"
                       L"Status=" << static_cast<int>(servicesResult.Status()) << std::endl;
        co_return;
    }

    // Using a range-based for loop instead of .Size()/.GetAt() to work
    // around an MSVC/C++-WinRT header-ordering bug (C3779: "a function
    // that returns 'auto' cannot be used before it is defined") that these
    // particular projected collection types trigger.
    GattDeviceService foundFtmsService{ nullptr };
    for (auto&& svc : servicesResult.Services()) {
        foundFtmsService = svc;
        break;
    }

    if (foundFtmsService == nullptr) {
        std::wcout << L"Could not find the Fitness Machine Service (0x1826) on this device.\n"
                       L"This treadmill may use a different/older protocol than expected, "
                       L"or Windows failed GATT discovery (try re-pairing in Windows Settings > Bluetooth)."
                    << std::endl;
        co_return;
    }

    g_ftmsService = foundFtmsService;
    std::wcout << L"Found FTMS service (0x1826)." << std::endl;

    GattCharacteristicsResult charResult =
        co_await g_ftmsService.GetCharacteristicsForUuidAsync(ShortUuid(TREADMILL_DATA_CHARACTERISTIC_UUID),
                                                                BluetoothCacheMode::Uncached);

    if (charResult.Status() != GattCommunicationStatus::Success) {
        std::wcout << L"Could not query the Treadmill Data characteristic.\n"
                       L"Status=" << static_cast<int>(charResult.Status()) << std::endl;
        co_return;
    }

    GattCharacteristic foundTreadmillDataChar{ nullptr };
    for (auto&& ch : charResult.Characteristics()) {
        foundTreadmillDataChar = ch;
        break;
    }

    if (foundTreadmillDataChar == nullptr) {
        std::wcout << L"Could not find the Treadmill Data characteristic (0x2ACD)." << std::endl;
        co_return;
    }

    g_treadmillDataChar = foundTreadmillDataChar;

    g_treadmillDataChar.ValueChanged([](GattCharacteristic const&, GattValueChangedEventArgs const& args) {
        DecodeAndPrintTreadmillData(args.CharacteristicValue());
    });

    GattCommunicationStatus notifyStatus = co_await g_treadmillDataChar.WriteClientCharacteristicConfigurationDescriptorAsync(
        GattClientCharacteristicConfigurationDescriptorValue::Notify);

    if (notifyStatus != GattCommunicationStatus::Success) {
        std::wcout << L"Failed to subscribe to notifications. Status=" << static_cast<int>(notifyStatus) << std::endl;
        co_return;
    }

    std::wcout << L"Subscribed to live Treadmill Data. Start walking/running on the TS100 to see updates.\n"
                   L"[p] pause/resume, [q] quit\n" << std::endl;
}

// Pausing does two things, in this order:
//   1. Flip g_paused immediately, client-side -- this alone guarantees
//      nothing prints anymore, with zero latency and no dependency on the
//      device cooperating.
//   2. Also write the CCCD (Notify <-> None) so the treadmill itself stops
//      pushing notifications over the air while paused -- a real BLE-level
//      pause, not just the app ignoring incoming data, and it saves the
//      device's radio some work in the meantime.
// This runs on the console-input thread and blocks briefly on the GATT
// write via .get() (a plain synchronous wait, not a coroutine) -- fine here
// since it's a small, fast local characteristic-configuration write.
void TogglePause() {
    if (g_treadmillDataChar == nullptr) {
        std::wcout << L"Not subscribed to the treadmill yet -- nothing to pause." << std::endl;
        return;
    }

    bool pausingNow = !g_paused.load();
    g_paused = pausingNow;
    std::wcout << (pausingNow ? L"\n[PAUSED] Notifications muted; unsubscribing from the device...\n"
                               : L"\n[RESUMED] Re-subscribing to the device...\n");

    auto value = pausingNow ? GattClientCharacteristicConfigurationDescriptorValue::None
                             : GattClientCharacteristicConfigurationDescriptorValue::Notify;
    GattCommunicationStatus status = g_treadmillDataChar.WriteClientCharacteristicConfigurationDescriptorAsync(value).get();

    if (status != GattCommunicationStatus::Success) {
        std::wcout << L"Warning: could not " << (pausingNow ? L"unsubscribe from" : L"re-subscribe to")
                    << L" the device (status=" << static_cast<int>(status)
                    << L"). Notifications remain muted locally either way." << std::endl;
    } else {
        std::wcout << (pausingNow ? L"Device notifications stopped.\n" : L"Device notifications resumed.\n") << std::endl;
    }
}

// Queries the Bluetooth radio Windows currently considers the "default"
// adapter and reports whether it actually supports BLE. Bluetooth 4.0+/BLE
// support is a hardware+driver capability, not something software can add,
// so this is the definitive check: if IsLowEnergySupported comes back
// false, no amount of code changes here will make discovery work with that
// adapter -- the fix is a different adapter (or a driver update).
//
// Caveat: GetDefaultAsync() returns exactly one adapter. If more than one
// Bluetooth radio is enabled at once (e.g. a built-in one plus a USB
// dongle), which one Windows treats as "default" is not something this API
// lets you choose -- to test a specific dongle, disable the others in
// Device Manager first so there's only one enabled at a time.
bool CheckAdapterSupportsBLE() {
    auto adapter = BluetoothAdapter::GetDefaultAsync().get();
    if (adapter == nullptr) {
        std::wcout << L"No Bluetooth radio found by Windows at all (GetDefaultAsync returned null).\n"
                       L"Check Settings > Bluetooth & devices, or Device Manager, for an enabled adapter.\n"
                    << std::endl;
        return false;
    }

    std::wcout << L"Default Bluetooth adapter: addr=" << HexAddress(adapter.BluetoothAddress())
               << L"\n  IsClassicSupported:    " << (adapter.IsClassicSupported() ? L"yes" : L"no")
               << L"\n  IsLowEnergySupported:  " << (adapter.IsLowEnergySupported() ? L"yes" : L"no")
               << L"\n  IsCentralRoleSupported:" << (adapter.IsCentralRoleSupported() ? L"yes" : L"no")
               << std::endl;

    if (!adapter.IsLowEnergySupported() || !adapter.IsCentralRoleSupported()) {
        std::wcout << L"\nThis adapter does NOT support BLE central role (the mode needed to scan for "
                       L"and connect to the treadmill as a client). This is a hardware/driver limit, not "
                       L"something this app can work around. If you have other adapters, disable this one "
                       L"in Device Manager and enable one of your external dongles instead, then re-run.\n"
                    << std::endl;
        return false;
    }

    std::wcout << L"This adapter supports BLE central role. Proceeding to scan...\n" << std::endl;
    return true;
}

} // namespace

int wmain() {
    winrt::init_apartment();

    // Runs for the whole process lifetime; detached since nothing needs to
    // join it -- the app exiting tears the socket down regardless.
    std::thread(TcpServerThreadProc).detach();

    if (!CheckAdapterSupportsBLE()) {
        std::wcout << L"Press Enter to exit." << std::endl;
        std::wcin.get();
        return 1;
    }

    // These live for the whole run of the program (wmain's scope spans the
    // std::wcin.get() wait below), unlike a fire-and-forget coroutine whose
    // locals -- including the watcher itself -- would be destroyed the
    // instant it returned, since nothing in it actually suspends.
    std::map<uint64_t, SeenInfo> seenAddresses;
    std::atomic<bool> connecting{ false };
    BluetoothLEAdvertisementWatcher watcher;

    try {
        watcher.ScanningMode(BluetoothLEScanningMode::Active);

        watcher.Received([&](BluetoothLEAdvertisementWatcher const&, BluetoothLEAdvertisementReceivedEventArgs const& args) {
            uint64_t address = args.BluetoothAddress();
            std::wstring name = args.Advertisement().LocalName().c_str();
            if (name.empty()) name = L"(no advertised name)";

            auto serviceUuids = args.Advertisement().ServiceUuids();
            bool hasFtms = HasFtmsService(serviceUuids);
            std::wstring uuidList = FormatServiceUuids(serviceUuids);

            // Print again whenever this packet adds information we hadn't
            // seen for this address yet (a name, or a service UUID list) --
            // some devices split this across multiple packets (primary
            // advertisement vs. scan response), so a plain "seen once"
            // dedup would hide exactly the data we need.
            auto& info = seenAddresses[address];
            bool isNewAddress = !info.logged;
            bool hasNewName = !name.empty() && name != L"(no advertised name)" && !info.hadName;
            bool hasNewUuids = !uuidList.empty() && !info.hadUuids;

            if (isNewAddress || hasNewName || hasNewUuids) {
                info.logged = true;
                if (hasNewName) info.hadName = true;
                if (hasNewUuids) info.hadUuids = true;

                std::lock_guard<std::mutex> lock(g_consoleMutex);
                std::wcout << L"Seen: \"" << name << L"\"  addr=" << HexAddress(address)
                           << L"  rssi=" << args.RawSignalStrengthInDBm() << L"dBm"
                           << L"  services=[" << uuidList << L"]"
                           << (hasFtms ? L"  <-- advertises FTMS (0x1826)" : L"")
                           << std::endl;
            }

            bool expected = false;
            bool isDomyos = name.rfind(L"DOMYOS", 0) == 0;
            if ((isDomyos || hasFtms) && connecting.compare_exchange_strong(expected, true)) {
                std::wcout << L">>> Candidate device found (name=\"" << name << L"\", FTMS="
                           << (hasFtms ? L"yes" : L"no") << L") - connecting..." << std::endl;
                ConnectAndSubscribe(address);
            }
        });

        std::wcout << L"Scanning for BLE advertisements ([q] to quit)...\n"
                       L"Make sure the TS100 console is awake (press a button / start the belt briefly)\n"
                       L"if it doesn't show up within a few seconds.\n"
                       L"Once connected: [p] pause/resume, [q] quit\n" << std::endl;
        watcher.Start();

        // _getch() reads one keypress with no Enter needed and without
        // echoing it to the console, so toggling pause doesn't clutter the
        // live data log with typed characters.
        while (true) {
            int ch = _getch();
            if (ch == 'q' || ch == 'Q') {
                break;
            } else if (ch == 'p' || ch == 'P') {
                TogglePause();
            }
        }
    } catch (const winrt::hresult_error& ex) {
        std::wcerr << L"WinRT error 0x" << std::hex << static_cast<uint32_t>(ex.code())
                   << L": " << ex.message().c_str() << std::endl;
        std::wcerr << L"\nCommon causes:\n"
                       L" - Bluetooth radio is off, or this PC has no BLE adapter\n"
                       L" - Access denied: try pairing the TS100 in Windows Settings > Bluetooth first\n"
                       L" - The device went out of range mid-connection\n";
        return 1;
    }

    return 0;
}
