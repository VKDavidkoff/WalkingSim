using UnityEngine;
using UnityEngine.XR;

// VR counterpart of the desktop prototype's PlayerMovement:
//   - Forward speed comes from the treadmill (TreadmillClient) whenever it is
//     connected and sending fresh data, scaled by treadmillSpeedMultiplier.
//   - Otherwise forward/back falls back to the controller thumbstick's Y axis,
//     so the game can be tested without running.
//   - Turning is always the thumbstick's X axis (the treadmill reports speed,
//     not direction).
// Movement follows this object's yaw (set by the thumbstick), not where the
// head is looking, matching the desktop version's tank-style feel.
[RequireComponent(typeof(CharacterController))]
public class VRPlayerMovement : MonoBehaviour
{
    public enum StickSource { Either, LeftOnly, RightOnly }
    public enum TurnMode { Smooth, Snap }

    [Header("Controller input")]
    [Tooltip("Either = whichever thumbstick is pushed further, so both controllers behave identically and the user just uses their dominant hand. Choose LeftOnly/RightOnly if the hand gripping the treadmill handle keeps nudging its stick.")]
    public StickSource stickSource = StickSource.Either;
    [Range(0f, 0.9f)] public float stickDeadzone = 0.2f;

    [Header("Turning (thumbstick left/right)")]
    public TurnMode turnMode = TurnMode.Smooth;
    public float smoothTurnDegPerSec = 90f;
    public float snapTurnDegrees = 30f;
    [Range(0.3f, 0.95f)] public float snapTriggerThreshold = 0.7f;

    [Header("Fallback movement (thumbstick forward/back) -- used when the treadmill isn't engaged")]
    public float fallbackMoveSpeed = 4f;

    [Header("Treadmill input")]
    [Tooltip("When on, forward speed comes from TreadmillClient (if connected and receiving fresh data); otherwise falls back to the thumbstick.")]
    public bool useTreadmillInput = true;
    [Tooltip("Scales the treadmill's real-world speed before it's applied in-game. Tunable live in Play mode.")]
    public float treadmillSpeedMultiplier = 2.0f;

    [Header("Physics")]
    public float gravity = -9.81f;

    private CharacterController controller;
    private float verticalVelocity;
    private bool snapLatched;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
    }

    void Update()
    {
        Vector2 stick = ReadStick();

        if (turnMode == TurnMode.Smooth)
        {
            transform.Rotate(0f, stick.x * smoothTurnDegPerSec * Time.deltaTime, 0f);
        }
        else
        {
            HandleSnapTurn(stick.x);
        }

        bool treadmillActive = useTreadmillInput && TreadmillClient.Instance != null && TreadmillClient.Instance.IsDataFresh;

        float forwardSpeed = treadmillActive
            ? TreadmillClient.Instance.SpeedMetersPerSecond * treadmillSpeedMultiplier
            : stick.y * fallbackMoveSpeed;

        Vector3 move = transform.forward * forwardSpeed;

        if (controller.isGrounded)
        {
            verticalVelocity = -0.5f;
        }
        else
        {
            verticalVelocity += gravity * Time.deltaTime;
        }
        move.y = verticalVelocity;

        controller.Move(move * Time.deltaTime);
    }

    // Latches after each snap so holding the stick over gives one turn, not
    // a continuous spin; releasing it back toward center re-arms it.
    private void HandleSnapTurn(float x)
    {
        if (!snapLatched && Mathf.Abs(x) >= snapTriggerThreshold)
        {
            transform.Rotate(0f, Mathf.Sign(x) * snapTurnDegrees, 0f);
            snapLatched = true;
        }
        else if (snapLatched && Mathf.Abs(x) < snapTriggerThreshold * 0.5f)
        {
            snapLatched = false;
        }
    }

    private Vector2 ReadStick()
    {
        bool haveLeft = false, haveRight = false;
        Vector2 left = Vector2.zero, right = Vector2.zero;

        if (stickSource != StickSource.RightOnly) haveLeft = TryGetStick(XRNode.LeftHand, out left);
        if (stickSource != StickSource.LeftOnly) haveRight = TryGetStick(XRNode.RightHand, out right);

        Vector2 chosen;
        if (haveLeft && haveRight) chosen = left.sqrMagnitude >= right.sqrMagnitude ? left : right;
        else if (haveLeft) chosen = left;
        else if (haveRight) chosen = right;
        else chosen = Vector2.zero;

        return chosen.magnitude < stickDeadzone ? Vector2.zero : chosen;
    }

    private static bool TryGetStick(XRNode node, out Vector2 value)
    {
        value = Vector2.zero;
        InputDevice device = InputDevices.GetDeviceAtXRNode(node);
        return device.isValid && device.TryGetFeatureValue(CommonUsages.primary2DAxis, out value);
    }
}
