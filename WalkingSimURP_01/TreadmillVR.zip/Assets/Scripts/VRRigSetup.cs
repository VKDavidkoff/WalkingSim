using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;

// Makes the headset's height line up with the rig: asks the XR runtime for a
// floor-relative tracking origin (head ~1.6m above the rig root), and if the
// runtime can't provide one, falls back to a fixed eye-height offset so the
// camera is never stuck at foot level. The XR subsystem can start a moment
// after the scene loads, so this retries for a few seconds before falling back.
public class VRRigSetup : MonoBehaviour
{
    [Tooltip("Parent of the camera. Its local height is the only thing this script moves.")]
    public Transform cameraOffset;
    public float fallbackEyeHeight = 1.6f;
    public float maxWaitSeconds = 4f;

    private readonly List<XRInputSubsystem> subsystems = new List<XRInputSubsystem>();
    private float waited;
    private float nextAttempt;
    private bool done;

    void Update()
    {
        if (done || cameraOffset == null) return;
        if (Time.unscaledTime < nextAttempt) return;
        nextAttempt = Time.unscaledTime + 0.5f;
        waited += 0.5f;

        SubsystemManager.GetSubsystems(subsystems);
        foreach (XRInputSubsystem subsystem in subsystems)
        {
            if (subsystem.TrySetTrackingOriginMode(TrackingOriginModeFlags.Floor))
            {
                cameraOffset.localPosition = Vector3.zero;
                done = true;
                return;
            }
        }

        if (waited >= maxWaitSeconds)
        {
            foreach (XRInputSubsystem subsystem in subsystems)
            {
                subsystem.TrySetTrackingOriginMode(TrackingOriginModeFlags.Device);
            }
            cameraOffset.localPosition = new Vector3(0f, fallbackEyeHeight, 0f);
            done = true;
        }
    }
}
