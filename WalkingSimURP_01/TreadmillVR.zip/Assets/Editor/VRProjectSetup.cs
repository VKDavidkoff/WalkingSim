using System;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.SceneManagement;
using UnityEditor.XR.Management;
using UnityEditor.XR.Management.Metadata;
using UnityEditor.XR.OpenXR.Features;
using UnityEngine;
using UnityEngine.SpatialTracking;
using UnityEngine.XR.Management;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.Features;
using UnityEngine.XR.OpenXR.Features.Interactions;
using UnityEngine.XR.OpenXR.Features.MetaQuestSupport;

// One-stop project setup, runnable from the command line (-executeMethod
// VRProjectSetup.SetupEverything) or from the Tools > VR menu. Everything
// here is idempotent, so re-running it is safe.
public static class VRProjectSetup
{
    [MenuItem("Tools/VR/Setup Everything (XR + Quest + Scene)")]
    public static void SetupEverything()
    {
        ConfigureXR();
        ConfigureAndroidPlayerSettings();
        BuildVRScene();
    }

    [MenuItem("Tools/VR/1. Configure XR (OpenXR, Touch controllers, Quest)")]
    public static void ConfigureXR()
    {
        // XR Management exposes GetOrCreate() only internally; there is no
        // public way to create the per-platform settings asset from code.
        MethodInfo getOrCreate = typeof(XRGeneralSettingsPerBuildTarget)
            .GetMethod("GetOrCreate", BindingFlags.NonPublic | BindingFlags.Static);
        var perTarget = (XRGeneralSettingsPerBuildTarget)getOrCreate.Invoke(null, null);

        // Standalone = Windows (Quest Link / Air Link in the Editor and in PC
        // builds); Android = the Quest's own standalone builds.
        foreach (BuildTargetGroup group in new[] { BuildTargetGroup.Standalone, BuildTargetGroup.Android })
        {
            if (!perTarget.HasManagerSettingsForBuildTarget(group))
            {
                perTarget.CreateDefaultManagerSettingsForBuildTarget(group);
            }

            XRManagerSettings manager = perTarget.ManagerSettingsForBuildTarget(group);
            bool assigned = XRPackageMetadataStore.AssignLoader(manager, typeof(OpenXRLoader).FullName, group);
            Debug.Log($"[VRProjectSetup] OpenXR loader for {group}: {(assigned ? "assigned" : "ALREADY ASSIGNED or FAILED -- check XR Plug-in Management")}");

            FeatureHelpers.RefreshFeatures(group);
            OpenXRSettings settings = OpenXRSettings.GetSettingsForBuildTargetGroup(group);

            EnableFeature<OculusTouchControllerProfile>(settings, group);
            if (group == BuildTargetGroup.Android)
            {
                EnableFeature<MetaQuestFeature>(settings, group);
            }
        }

        AssetDatabase.SaveAssets();
    }

    private static void EnableFeature<T>(OpenXRSettings settings, BuildTargetGroup group) where T : OpenXRFeature
    {
        T feature = settings != null ? settings.GetFeature<T>() : null;
        if (feature == null)
        {
            Debug.LogWarning($"[VRProjectSetup] {typeof(T).Name} not found for {group}; enable it manually in Project Settings > XR Plug-in Management > OpenXR.");
            return;
        }

        feature.enabled = true;
        EditorUtility.SetDirty(feature);
        Debug.Log($"[VRProjectSetup] Enabled {typeof(T).Name} for {group}.");
    }

    [MenuItem("Tools/VR/2. Apply Quest 2 Android player settings")]
    public static void ConfigureAndroidPlayerSettings()
    {
        TrySet("IL2CPP scripting backend", () => PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP));
        TrySet("ARM64 only", () => PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64);
        TrySet("Min API 29", () => PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel29);
        // The treadmill data arrives over TCP, so the app needs the INTERNET permission.
        TrySet("Internet access: Require", () => PlayerSettings.Android.forceInternetPermission = true);
        TrySet("Linear color space", () => PlayerSettings.colorSpace = ColorSpace.Linear);
        TrySet("Product name", () => PlayerSettings.productName = "TreadmillVR");
    }

    private static void TrySet(string what, Action apply)
    {
        try
        {
            apply();
            Debug.Log($"[VRProjectSetup] Set: {what}");
        }
        catch (Exception ex)
        {
            Debug.LogWarning($"[VRProjectSetup] Could not set '{what}': {ex.Message}");
        }
    }

    [MenuItem("Tools/VR/3. Rebuild VR Test Scene")]
    public static void BuildVRScene()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground";
        ground.transform.localScale = new Vector3(10f, 1f, 10f);

        GameObject lightGO = new GameObject("Directional Light");
        Light light = lightGO.AddComponent<Light>();
        light.type = LightType.Directional;
        lightGO.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

        // Rig root sits on the floor: the CharacterController capsule spans
        // 0..1.8m above it, and the camera hangs below "Camera Offset".
        GameObject rig = new GameObject("Player");
        rig.transform.position = new Vector3(0f, 0.05f, 0f);
        CharacterController cc = rig.AddComponent<CharacterController>();
        cc.height = 1.8f;
        cc.radius = 0.3f;
        cc.center = new Vector3(0f, 0.9f, 0f);
        rig.AddComponent<VRPlayerMovement>();
        VRRigSetup rigSetup = rig.AddComponent<VRRigSetup>();

        GameObject cameraOffset = new GameObject("Camera Offset");
        cameraOffset.transform.SetParent(rig.transform, false);
        rigSetup.cameraOffset = cameraOffset.transform;

        GameObject camGO = new GameObject("Main Camera");
        camGO.tag = "MainCamera";
        camGO.transform.SetParent(cameraOffset.transform, false);
        Camera cam = camGO.AddComponent<Camera>();
        cam.nearClipPlane = 0.1f;
        camGO.AddComponent<AudioListener>();

        TrackedPoseDriver head = camGO.AddComponent<TrackedPoseDriver>();
        head.SetPoseSource(TrackedPoseDriver.DeviceType.GenericXRDevice, TrackedPoseDriver.TrackedPose.Center);
        head.trackingType = TrackedPoseDriver.TrackingType.RotationAndPosition;
        head.updateType = TrackedPoseDriver.UpdateType.UpdateAndBeforeRender;

        GameObject treadmillClientGO = new GameObject("TreadmillClient");
        treadmillClientGO.AddComponent<TreadmillClient>();

        Directory.CreateDirectory("Assets/Scenes");
        EditorSceneManager.SaveScene(scene, "Assets/Scenes/VRTestScene.unity");
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene("Assets/Scenes/VRTestScene.unity", true) };

        Debug.Log("[VRProjectSetup] VRTestScene created and saved.");
    }
}
